Sample SQL scripts I have written to automate reporting

1. **[RFM Analysis](https://github.com/DataSolveProblems/Jie-s-Data-Analysis-Portfolio/blob/main/Analysis%20(reports)/RFM%20Analysis.sql)**
2. **[Dynamic SQL](https://github.com/DataSolveProblems/Jie-s-Data-Analysis-Portfolio/blob/main/Analysis%20(reports)/dynamic%20SQL.sql)**
